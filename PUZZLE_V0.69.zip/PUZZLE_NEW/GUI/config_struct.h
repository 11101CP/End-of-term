#ifndef CONFIG_STRUCT_H_
#define CONFIG_STRUCT_H_

#include "../AL_general.h"
#include "../common.h"
#include "GUI.h"


typedef enum
{
ConfigFULLSCREEN=0,
ConfigRESOLUTION=1,
ConfigPLAY=2,
ConfigQUIT=3,
}ButtonName;


/***config_window.c***/
bool configUI(CONFIG *config);
int getButtonClick(ALLEGRO_MOUSE_EVENT *mouse,UIButton *button);


/***config_build.c***/
void loadButton(UIButton *button,float unit);
void loadUIResource(UIRESOURCE *res,int unit);
void destroyUIResource(UIRESOURCE *res);
void buildDropDownMenu(DropDownMenu *menu,int number);
int getScreenInfo (void);



/***config_draw.c***/
void drawConfigMenu(UIRESOURCE *res,UIButton *button,DropDownMenu *menu,int unit);


#endif // CONFIG_STRUCT_H_
