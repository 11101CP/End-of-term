#include "Common.h"
#include "AL_general.h"
#include "Game_frame.h"

bool Game (CONFIG *config,STAGE *stage,RESOURCE *res)
{
puts("hihi");
}
