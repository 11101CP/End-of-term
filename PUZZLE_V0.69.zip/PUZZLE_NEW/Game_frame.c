#include "Common.h"
#include "AL_general.h"
#include "Game_frame.h"

void stageBOSS (BOX ***box);

void loadBox  (BOX ***box,int x,int y,int unit);
void buildBox (BOX ****box,int x,int y);


bool gameSetUp(CONFIG *config,RESOURCE *res)
{
    int stageChoose=1;
    STAGE stage;

    loadStage(&stage , config,stageChoose);

   bool mode=true;

    while(mode)
{


     loadStage(&stage , config,stageChoose);
        if(Fight(config,&stage,res))
            stageChoose++;
     clearStage(&stage );
}

    //destroyStageRes
    //destroyStage
}

void loadBox  (BOX ***box,int x,int y,int unit) //stage 1
{
    int i,j;
    for(i=0;i<x;i++)
        for(j=0;j<y;j++)
        {
            box[i][j]->x= (40+9*i)*unit;
            box[i][j]->y= (4+9*j)*unit;
            box[i][j]->state = EMPTY;
            box[i][j]->damage = NO;
        }



}


void buildBox (BOX ****box,int x,int y)
{
    int i,j;

    BOX ***row=NULL;
    BOX **col=NULL;
    BOX *item=NULL;

    row=calloc(x,sizeof(BOX **));

    for(i=0;i<x;i++)
    {
        col=calloc (y,sizeof(BOX *));
        for(j=0;j<y;j++)
        {
            item=calloc(1,sizeof(BOX));
            col[j]=item;
        }
        row[i]=col;

    }

    *box=row;
}
