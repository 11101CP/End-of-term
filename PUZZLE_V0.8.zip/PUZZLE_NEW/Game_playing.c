#include "Common.h"
#include "AL_general.h"
#include "Game_frame.h"

void TrapFunc(STAGE *stage,RESOURCE *res,CONFIG *config)
{
    BOX*** box=stage->box;
    int x,y;
for (x=0;x<stage->boxNumX;x++)
    for(y=0;y<stage->boxNumY;y++)
        if(box[x][y]->element==FlexibleTrap)
        if(box[x][y]->damage)
            box[x][y]->damage=false;
        else
            {box[x][y]->damage=true;
            if (box[x][y]->state==MONSTER)
                {box[x][y]->state=EMPTY;
                 al_play_sample(res->MonsterDie,1,0,1,ALLEGRO_PLAYMODE_ONCE,NULL);}
            }




}
