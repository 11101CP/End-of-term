#include "Common.h"
#include "AL_general.h"



int main()
{

    al_setup();

    CONFIG config;
    RESOURCE res;
    config.stage=9;
    int progress=1;





    if( ! configUI(&config,&res) )
        return 0;                   //end if user press quit

//    preGameSetup(&res,&config);

    //gameSetUp(&config,&res,progress);

    if(config.fullscreen)
    {al_set_new_display_flags(ALLEGRO_WINDOWED);
    al_set_new_display_flags(ALLEGRO_RESIZABLE);
    res.display =al_create_display(160*config.unit,90*config.unit);
    al_set_display_flag(res.display,ALLEGRO_FRAMELESS,true);
        al_set_display_flag(res.display,ALLEGRO_MAXIMIZED,true);
    }
    else   res.display=al_create_display(160*config.unit,90*config.unit);

    res.object=al_load_bitmap("./assets/object.png");
    res.block=al_load_bitmap("./Brick.png");
    res.belt=al_load_bitmap("./belt.png");
    res.chara=al_load_bitmap("./duck.png");

    res.fonts=al_load_font("./ASDD.ttf",config.unit*15,0);

    res.FlexSpikeOn=al_load_bitmap("./SpikeOn.png");
    res.FlexSpikeOff=al_load_bitmap("./SpikeOff.png");

    res.CharaHitten=al_load_sample("./Chara_Hitten.wav");
    res.CharaMove=al_load_sample("./Chara_Moving.wav");
    res.ObjHitten=al_load_sample("./Hit_Object_Sound.wav");
    res.DoorOpen=al_load_sample("./Door_Open.wav");
    res.MonsterHitten=al_load_sample("./Monster_Hitten.wav");
    res.MonsterDie=al_load_sample("./Monster_Die.wav");
    res.GamePause=al_load_sample("./Game_Pause.wav");
    res.GameRestart=al_load_sample("./Game_Restart.wav");

    res.Stage_1=al_load_bitmap("./stage1.png");
    res.Stage_2=al_load_bitmap("./stage2.png");
    res.Stage_3=al_load_bitmap("./stage3.png");
    res.Stage_4=al_load_bitmap("./stage4.png");
    res.Stage_5=al_load_bitmap("./stage5.png");
    res.Stage_6=al_load_bitmap("./stage6.png");
    res.Stage_7=al_load_bitmap("./stage7.png");
    res.Stage_8=al_load_bitmap("./stage8.png");

    //al_draw_text(res.fonts,al_map_rgb(255,255,255),0,0,0,"50");

    gameSetUp(&config,&res);




    al_cleanup();
    return 0;
}



